package com.example.androidpopupwindowexample

data class FilterItem(val icon:Int,val name: String)