package com.velmurugan.autocompleteexample

data class Movie(val name: String, val imageUrl: String, val category: String)