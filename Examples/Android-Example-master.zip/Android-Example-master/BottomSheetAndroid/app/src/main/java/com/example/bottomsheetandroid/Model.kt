package com.example.bottomsheetandroid

data class Item(val name: String, val image: Int)