package com.velmurugan.cardviewandroidkotlin

data class Movie(var title: String, var image: Int, var rating: Float)