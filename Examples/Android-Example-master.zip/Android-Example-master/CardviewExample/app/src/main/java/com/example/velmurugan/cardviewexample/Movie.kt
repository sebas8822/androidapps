package com.example.velmurugan.cardviewexample

data class Movie(var title: String, var image: Int)