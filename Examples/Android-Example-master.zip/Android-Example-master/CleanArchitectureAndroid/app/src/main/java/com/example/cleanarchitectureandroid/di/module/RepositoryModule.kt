package com.example.cleanarchitectureandroid.di.module

import com.example.cleanarchitectureandroid.data.MovieRepositoryImpl
import dagger.Module
import dagger.Provides

