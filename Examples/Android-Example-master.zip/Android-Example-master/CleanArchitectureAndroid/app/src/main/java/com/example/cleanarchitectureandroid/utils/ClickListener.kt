package com.example.cleanarchitectureandroid.utils

interface ClickListener<T> {
    fun onCLick(data: T)
}