package com.velmurugan.draganddroprecyclerviewitemandroid

data class User(val name: String, val location: String, val age: Int)