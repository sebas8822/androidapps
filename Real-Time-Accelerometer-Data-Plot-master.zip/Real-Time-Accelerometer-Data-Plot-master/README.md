# Real-Time-Accelerometer-Data-Plot
Here is sample code of real time accelerometer data plot on android mobile using mpandroidchart library.

This project is updated on 23th Jun 2020 (by jamilxt) and it is tested. Please watch video here https://www.youtube.com/watch?v=QEbljbZ4dNs

If you get an error something like this
```
org.gradle.api.UncheckedIOException: Failed to capture snapshot of input files for task ':app:mergeDebugResources' property 'aapt2FromMaven' during up-to-date check.
```

Follow this link: https://stackoverflow.com/questions/50967831/org-gradle-api-uncheckedioexception-failed-to-capture-snapshot-of-input


