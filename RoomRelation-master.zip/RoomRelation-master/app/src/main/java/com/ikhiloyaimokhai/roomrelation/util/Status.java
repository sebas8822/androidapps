package com.ikhiloyaimokhai.roomrelation.util;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
