package com.csu.demo.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeatherDao {

    //data access object

    @Query("SELECT * FROM weather_table ORDER BY ID")
    List<WeatherData> loadAllWeatherData();

    @Insert
    void insertWeatherData(WeatherData weatherData);

    @Update
    void updateWeatherData(WeatherData weatherData);

    @Delete
    void delete(WeatherData weatherData);

    @Query("SELECT * FROM weather_table WHERE id = :id")
    WeatherData loadWeatherDataById(int id);

    @Query("SELECT * FROM weather_table ORDER BY ID DESC LIMIT 1")
    WeatherData loadLastWeather();
}
