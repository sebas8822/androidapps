package com.csu.demo.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weather_table")
public class WeatherData {

    //create an auto generating id which will be our primary key
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "timeUpdated")
    private String time;
    private String temperature;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getWeatherDescription() {
        return weatherDescription;
    }

    public void setWeatherDescription(String weatherDescription) {
        this.weatherDescription = weatherDescription;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    private String weatherDescription;
    private String address;

    public WeatherData(String time, String temperature, String weatherDescription, String address) {
        this.time = time;
        this.temperature = temperature;
        this.weatherDescription = weatherDescription;
        this.address = address;
    }
}
