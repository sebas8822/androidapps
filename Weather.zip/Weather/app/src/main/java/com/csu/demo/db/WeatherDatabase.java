package com.csu.demo.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {WeatherData.class}, version = 1, exportSchema = false)
public abstract class WeatherDatabase extends RoomDatabase {
    // below line is to create instance
    // for our database class.
    private static WeatherDatabase instance;
    private static final String DATABASE_NAME = "weather_database";

    // below line is to create
    // abstract variable for dao.
    public abstract WeatherDao weatherDao();

    // this method always returns the same instance of
    public static synchronized WeatherDatabase getInstance(Context context) {
        // below line is to check if
        // the instance is null or not.
        if (instance == null) {
            // if the instance is null we create a new instance
            instance =
                    // create a room databse instance with database builder where we pass
                    //application context, our actual database and the name of the database
                    // for creating a instance for our database
                    Room.databaseBuilder(context.getApplicationContext(),
                                    WeatherDatabase.class, DATABASE_NAME)
                            // When the database version on the device does not match the latest schema version,
                            // Room runs necessary Migrations on the database. To avoid this we use the
                            //following code
                            .fallbackToDestructiveMigration()
                            // build our database.
                            .build();
        }
        // after creating an instance
        // we are returning our instance
        return instance;
    }
}
