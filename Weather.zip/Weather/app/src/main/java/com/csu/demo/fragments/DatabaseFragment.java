package com.csu.demo.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.csu.demo.AppExecutors;
import com.csu.demo.R;
import com.csu.demo.db.WeatherData;
import com.csu.demo.db.WeatherDatabase;
import com.csu.demo.fragments.adapter.WeatherAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class DatabaseFragment extends Fragment implements WeatherAdapter.RecyclerViewClickListener {

    WeatherAdapter weatherAdapter;
    WeatherDatabase weatherDatabase;
    List<WeatherData> weatherDataList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for database fragment
        View view = inflater.inflate(R.layout.fragment_database, container, false);

        weatherDatabase = WeatherDatabase.getInstance(getActivity().getApplicationContext());

        RecyclerView recyclerView = view.findViewById(R.id.weather_rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        weatherAdapter = new WeatherAdapter(getActivity(), this::recyclerViewListClicked);
        recyclerView.setAdapter(weatherAdapter);
        getWeatherData();
        return view;
    }

    private void getWeatherData() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            weatherDataList = weatherDatabase.weatherDao().loadAllWeatherData();
            getActivity().runOnUiThread(() -> weatherAdapter.setWeatherData(weatherDataList));
        });
    }

    @Override
    public void recyclerViewListClicked(View v, int position) {
        deleteWeatherData(position);
        getWeatherData();
        Toast.makeText(getActivity(), "Position is :" + position, Toast.LENGTH_SHORT).show();
    }

    private void deleteWeatherData(int position) {
        AppExecutors.getInstance().diskIO().execute(() ->
                weatherDatabase.weatherDao().delete(weatherDataList.get(position)));
    }
}