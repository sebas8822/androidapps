package com.csu.demo.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;

import com.csu.demo.AppExecutors;
import com.csu.demo.R;
import com.csu.demo.db.WeatherData;
import com.csu.demo.db.WeatherDatabase;
import com.csu.demo.network.HttpRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SearchFragment extends Fragment {

    String CITY = "Sydney";
    String API = "ff05f3442522acbe95a625485f2927d0";
    String response = null;

    TextView addressTxt, updated_atTxt, statusTxt, tempTxt, errorTxt;
    ProgressBar progressBar;
    RelativeLayout mainContainer;
    SearchView searchView;

    WeatherDatabase weatherDatabase;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for Search fragment
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        addressTxt = view.findViewById(R.id.address);
        updated_atTxt = view.findViewById(R.id.updated_at);
        statusTxt = view.findViewById(R.id.status);
        tempTxt = view.findViewById(R.id.temp);
        progressBar = view.findViewById(R.id.loader);
        mainContainer = view.findViewById(R.id.mainContainer);
        errorTxt = view.findViewById(R.id.errorText);
        searchView = view.findViewById(R.id.searchView);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                loadWeatherData(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        weatherDatabase = WeatherDatabase.getInstance(getActivity().getApplicationContext());
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadLastWeather();
    }

    private void showLoadingUI() {
        progressBar.setVisibility(View.VISIBLE);
        errorTxt.setVisibility(View.GONE);
    }

    private void loadWeatherData(String query) {
        showLoadingUI();

        HandlerThread handlerThread = new HandlerThread("URLConnection");
        handlerThread.start();
        Handler mainHandler = new Handler(handlerThread.getLooper());
        Runnable myRunnable = () -> {
            response = HttpRequest.getWeatherData("https://api.openweathermap.org/data/2.5/weather?q=" + query + "&units=metric&appid=" + API);
            populateViewWithData(response);
        };
        mainHandler.post(myRunnable);
    }

    private void populateViewWithData(String response) {
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONObject main = jsonObj.getJSONObject("main");
            JSONObject sys = jsonObj.getJSONObject("sys");
            JSONObject weather = jsonObj.getJSONArray("weather").getJSONObject(0);

            Long updatedAt = jsonObj.getLong("dt");
            String updatedAtText = "Updated at: " + new SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.ENGLISH).format(new Date(updatedAt * 1000));
            int roundedTemp = (int) (Double.parseDouble(main.getString("temp")));
            String temp = roundedTemp + "°C";

            String weatherDescription = weather.getString("description");

            String address = jsonObj.getString("name") + ", " + sys.getString("country");


            populateTheViews(updatedAtText, temp, weatherDescription, address);
            insertData(updatedAtText, temp, weatherDescription, address);

        } catch (Exception e) {
            handleException();
        }
    }

    private void handleException() {
        getActivity().runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            mainContainer.setVisibility(View.GONE);
            errorTxt.setVisibility(View.VISIBLE);
        });
    }

    private void populateTheViews(String updatedAtText, String temp, String weatherDescription, String address) {
        getActivity().runOnUiThread(() -> {
            /* Views populated, Hiding the loader, Showing the main design */
            progressBar.setVisibility(View.GONE);
            mainContainer.setVisibility(View.VISIBLE);

            /* Populating extracted data into our views */
            changeBackground(weatherDescription, updatedAtText);
            addressTxt.setText(address);
            updated_atTxt.setText(updatedAtText);
            statusTxt.setText(weatherDescription.toUpperCase() + " AT");
            tempTxt.setText(temp);

        });
    }

    private void loadLastWeather() {
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                WeatherData weatherData = weatherDatabase.weatherDao().loadLastWeather();
                if (weatherData != null) {
                    populateTheViews(weatherData.getTime(), weatherData.getTemperature(), weatherData.getWeatherDescription(), weatherData.getAddress());
                }
            }
        });
    }

    private void changeBackground(String weatherDescription, String updatedAt) {
        if (weatherDescription.contains("cloud") || weatherDescription.contains("rain")) {
            mainContainer.setBackground(getActivity().getDrawable(R.drawable.cloudy));
        } else {
            mainContainer.setBackground(getActivity().getDrawable(R.drawable.sunny));
        }

    }

    private void insertData(String updatedAtText, String temp, String weatherDescription, String address) {
        WeatherData weatherData = new WeatherData(updatedAtText, temp, weatherDescription, address);
        weatherDatabase.weatherDao().insertWeatherData(weatherData);
        Toast.makeText(getActivity(), "Database method called", Toast.LENGTH_SHORT);
    }
}
