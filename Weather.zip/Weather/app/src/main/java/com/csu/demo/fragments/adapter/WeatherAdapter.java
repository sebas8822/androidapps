package com.csu.demo.fragments.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.csu.demo.R;
import com.csu.demo.db.WeatherData;

import java.util.List;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.WeatherViewHolder> {
    private List<WeatherData> weatherData;
    private LayoutInflater inflater;
    private RecyclerViewClickListener itemListener;

    public WeatherAdapter(Context context, RecyclerViewClickListener itemListener) {
        this.inflater = LayoutInflater.from(context);
        this.itemListener = itemListener;
    }

    @NonNull
    @Override
    public WeatherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.rv_weather_item, parent, false);
        return new WeatherViewHolder(view, itemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull WeatherViewHolder holder, int position) {
        holder.address.setText(weatherData.get(position).getAddress());
        holder.time.setText(weatherData.get(position).getTime());
        holder.temperature.setText(weatherData.get(position).getTemperature());
        holder.weatherDescription.setText(weatherData.get(position).getWeatherDescription());
    }

    @Override
    public int getItemCount() {
        if (weatherData == null) {
            return 0;
        }
        return weatherData.size();
    }

    public void setWeatherData(List<WeatherData> weatherData) {
        this.weatherData = weatherData;
        notifyDataSetChanged();
    }

    //first create a view holder
    class WeatherViewHolder extends RecyclerView.ViewHolder {
        TextView address, time, temperature, weatherDescription;
        ImageView deleteImg;
        RecyclerViewClickListener recyclerViewClickListener;

        public WeatherViewHolder(@NonNull View itemView, RecyclerViewClickListener recyclerViewClickListener) {
            super(itemView);
            address = itemView.findViewById(R.id.rv_address);
            time = itemView.findViewById(R.id.rv_time);
            temperature = itemView.findViewById(R.id.rv_temperature);
            weatherDescription = itemView.findViewById(R.id.rv_weather_description);
            deleteImg = itemView.findViewById(R.id.rv_img_delete);
            this.recyclerViewClickListener = recyclerViewClickListener;
            deleteImg.setOnClickListener(v ->
                    recyclerViewClickListener.recyclerViewListClicked(v, getAdapterPosition()));
        }

    }

    //define one interface 'RecyclerViewClickListener' for passing message from adapter to Activity/Fragment:
    public interface RecyclerViewClickListener {
        void recyclerViewListClicked(View v, int position);
    }


}
