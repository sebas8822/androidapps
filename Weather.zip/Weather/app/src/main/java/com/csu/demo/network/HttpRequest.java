package com.csu.demo.network;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpRequest {

    public static String getWeatherData(String targetURL) {
        URL url;
        HttpURLConnection connection = null;
        try {
            //convert string url to actual URL
            url = new URL(targetURL);
            //open HttpUrlConnection
            connection = (HttpURLConnection) url.openConnection();
            //set GET request method
            connection.setRequestMethod("GET");

            InputStream is;
            //get Response code
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK)
                is = connection.getErrorStream();
            else
                //open input stream if no error
                is = connection.getInputStream();
            //read data as string
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            String line;
            StringBuffer response = new StringBuffer();
            while ((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }
            rd.close();
            Log.d("API RESPONSE", response.toString());
            return response.toString();
        } catch (Exception e) {
            Log.d("API RESPONSE", e.getMessage());
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
