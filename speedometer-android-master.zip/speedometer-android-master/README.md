# speedometer-android
Speedometer is a no-nonsense Digital Speedometer. Supports four different velocity unit (km/h, mph, knots and meter/second).

It does what it said on the tin and does not require unnecessary permissions


## Advantages
* Lightweight
* Only require GPS permission for detecting speed 
* No unobtrusive ads
* Does exactly what it said on the tin, nothing more, nothing less :p 

## Download
[Get it on Google Play] (https://play.google.com/store/apps/details?id=net.mypapit.mobile.speedmeter)

