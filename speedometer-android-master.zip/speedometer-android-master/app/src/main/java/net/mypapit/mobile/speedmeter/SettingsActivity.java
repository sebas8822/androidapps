package net.mypapit.mobile.speedmeter;

import android.os.Bundle;
import android.preference.PreferenceActivity;

public class SettingsActivity extends PreferenceActivity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.set);

    }

    //171143
    //Faculty of Computer Science and Information Technology University of Malaya 50603 Lembah Pantai Kuala Lumpur MALAYSIA
}
